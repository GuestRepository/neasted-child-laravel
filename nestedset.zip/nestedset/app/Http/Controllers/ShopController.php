<?php

namespace App\Http\Controllers;

use App\Models\Shop;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ShopController extends Controller
{
    public function index()
    {
        $shops = Shop::get()->toTree();
        return $shops;
    }

    public function requestCategories($id)
    {
         $shop = Shop::descendantsAndSelf($id)->toTree()->first();
        // $shop = Shop::descendantsAndSelf($id);//->toTree();
        Log::info('waht is coming by request id :  '.$shop);
        return $shop;
    }

}
